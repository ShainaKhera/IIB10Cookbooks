`ibm_integration_bus` CHANGELOG
===========================

This file is used to list changes made in each version of the `ibm_integration_bus` cookbook.

1.0.0
-----
- [John Reeve] - Initial release of `ibm_integration_bus`

1.0.1
-----
- [John Reeve] - Add ability to allow IIB node parameters to be change from default values.

1.0.2
-----
- [Imran Shakir] - Add Test Kitchen support

1.0.3
-----
- [Alasdair Paton] - Support fixpack refreshes of IIB 9.0 Developer Edition
