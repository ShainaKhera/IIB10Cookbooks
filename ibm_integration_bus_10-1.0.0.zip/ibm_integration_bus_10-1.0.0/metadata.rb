name             'ibm_integration_bus_10'
maintainer       'Saurabh Ghosh'
maintainer_email 'saurabh.a.ghosh@accenture.com'
license          'Accenture'
description      'Installs/Configures IBM Integration Bus'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.0.0'
